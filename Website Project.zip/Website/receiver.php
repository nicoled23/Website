<?php
echo "The form was received by:".$_POST['recipient']."</br>";
echo "The subject is :". $_POST['subject']. "</br>";
echo "The name entered is: ".$_POST['name'];
?>
